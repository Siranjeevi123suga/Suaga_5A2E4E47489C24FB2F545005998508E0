def linearsearchproduct(productlist,targetproduct) : 
indices = []
for index, product in enumerate(product list):
if product == target product:
return indices 
#Example usage: 
Product = ["shoes","boot","laafer","shoes","shoes","sandal","shoes"]
target = "shoes"
result = linearsearchproduct(product, target)
print (result)